getwd()
install.packages("arules")
library(arules)
#数据初探

groceries<-read.transactions("groceries.csv",sep=",")

summary(groceries)

inspect(groceries[1:6])

itemFrequency(groceries[,1:3])

#可视化交易数据

#可视化商品的支持度
itemFrequencyPlot(groceries,support=0.1)
itemFrequencyPlot(groceries,topN=15)

#可视化稀疏矩阵
image(groceries[1:20])
image(sample(groceries,100))

#挖掘关联规则
groceryrules<-apriori(groceries,parameter=list(support=0.01,confidence=0.5, minlen=2))

groceryrules

summary(groceryrules)

inspect(groceryrules[1:6])

inspect(sort(groceryrules,by="confidence")[1:6])

yogurtrules<-subset(groceryrules,items%in%"yogurt")
inspect(yogurtrules)

itemsets_apr=apriori(groceries,parameter=list(supp=0.01,target="frequent itemsets"), control= list(sort=-1))
         
itemsets_apr 

inspect(itemsets_apr[1:6]) 

write(groceryrules,file="groceryrules.csv",sep=",",quote=TRUE,row.names=FALSE)

#可视化关联规则
install.packages("arulesViz")     #安装关联规则可视化添加包
library(arulesViz)               	#加载关联规则可视化添加包
plot(groceryrules)                #可视化groceryrules

#变换横、纵轴及颜色条对应的变量，绘制groceryrules散点图
plot(groceryrules,measure=c("support","lift"),shading="confidence")

#绘制互动散点图
plot(groceryrules,interactive=TRUE)

plot(groceryrules,shading="order",control=list(main="Two-key plot"))

plot(groceryrules,method="grouped")

plot(groceryrules,method="matrix",measure="lift")

plot(groceryrules,method="matrix3D",measure="lift")

plot(groceryrules,method="paracoord")


#使用igraph软件包绘制散点图
install.packages("igraph")          #安装igraph添加包
library(igraph)                     #加载igraph添加包
plot(groceryrules,method="graph")

