#数据集初探
wine<-read.csv("Whitewines.csv")
str(wine)

#数值型变量探索
summary(wine$quality)

hist(wine$quality)

summary(wine[c("fixed.acidity","volatile.acidity","citric.acid")])

var=c(1:12)                               			#设置列变量的列号向量var
cor_matrix=cor(wine[var],use="pairwise")      	#对12个变量两两计算相关系数
cor_matrix                               		  	#显示相关系数矩阵

#数据转换与分区
normalize<-function(x){return((x-min(x))/(max(x)-min(x)))}
wine_norm<-as.data.frame(lapply(wine,normalize))

summary(wine_norm$quality)

wine_train<-wine_norm[1:3429,]
wine_test<-wine_norm[3430:4898,]

#模型构建与评价
install.packages("neuralnet")
library(neuralnet)

#第1个模型
wine_net1<-neuralnet(quality~.,data=wine_train)
plot(wine_net1)

wine_net1$result.matrix

wine_net1results<-compute(wine_net1,wine_test)
predicted_quality1<- wine_net1results$net.result
cor(predicted_quality1,wine_test$quality)

#第2个模型
wine_net2<-neuralnet(quality~.,data=wine_train,hidden=5)
plot(wine_net2)

wine_net2$result.matrix

wine_net2results<-compute(wine_net2,wine_test)
predicted_quality2<-wine_net2results$net.result
cor(predicted_quality2,wine_test$quality)

MAE<-function(actual,predicted){mean(abs(actual-predicted))}
MAE(predicted_quality1,wine_test$quality)
MAE(predicted_quality2,wine_test$quality)
