#数据集初探
credit<-read.csv("credit.csv",stringsAsFactors = TRUE)
str(credit)

#类别型变量探索

#单变量
table(credit$default)
table(credit$credit_history)
table(credit$purpose)
table(credit$job)

#双变量
table(credit$default,credit$credit_history)
table(credit$default,credit$checking_balance)
table(credit$default,credit$savings_balance)

#数值型变量探索

#单变量
summary(credit$age)

#多变量
summary(credit[c("months_loan_duration","amount")])

#统计图

#如果是Mac系统，为显示后续图中的中文，可先执行29-35，再作直方图及散点图
#install.packages("showtext")
#library(showtext)
#使用下面的函数查看所有字体,选择中文字体添加
#font_files()
#showtext_auto(enable = TRUE)
#font_add('Songti', 'Songti.ttc','STKaiti','STXihei')  #添加中文字体
#quartz(family = "STXihei") 
#可以把STXihei替换成任意想要的字体，如'Songti', 'Songti.ttc','STKaiti'等

#直方图
hist(credit$age,main="年龄直方图",xlab="age(岁)")
hist(credit$months_loan_duration,main="贷款期限直方图",xlab="loan_duration(月)")
hist(credit$amount,main="贷款金额直方图",xlab="amount(马克)")

#散点图
plot(x=credit$age,y=credit$months_loan_duration,main="年龄与贷款期限散点图",
     xlab="age(岁)",ylab="loan_duration(月)")
plot(x=credit$age,y=credit$amount,main="年龄与贷款金额散点图", 
     xlab="age(岁)",ylab="amount(马克)")
plot(x=credit$amount,y=credit$months_loan_duration,main="贷款金额与贷款期限散点
        图",xlab="amount(马克)",ylab="loan_duration(月)")

#数据分区

set.seed(123456)        #生成随机种子
credit_rand<-credit[order(runif(1000)),]

head(credit$age)
head(credit_rand$age)

summary(credit$age)
summary(credit_rand$age)

credit_train<-credit_rand[1:800,]
credit_test<-credit_rand[801:1000,]

prop.table(table(credit_train$default))
prop.table(table(credit_test$default))

#模型训练与评估

#模型训练
#安装C50添加包并加载
install.packages("C50")
library(C50)

credit_treemodel<-C5.0(credit_train[-17],credit_train$default)

credit_treemodel
summary(credit_treemodel)

#模型评估
credit_pred<-predict(credit_treemodel,credit_test)
install.packages("gmodels")
library(gmodels)
CrossTable(credit_test$default,credit_pred,prop.chisq=FALSE,prop.c=FALSE,prop.r=FALSE,dnn=c('actual default','predicted default'))

#使用boosting调整模型
credit_treeboost10<-C5.0(credit_train[-17],credit_train$default,trials=10)
credit_treeboost10

summary(credit_treeboost10)

credit_treeboost10_pred<-predict(credit_treeboost10,credit_test)
CrossTable(credit_test$default,credit_treeboost10_pred,prop.chisq=FALSE,
           prop.c=FALSE,prop.r=FALSE,dnn=c('actual default','predicted default'))

#使用代价矩阵调整模型
#建立代价矩阵
matrix_dimensions<-list(c("no","yes"),c("no","yes"))
names(matrix_dimensions)<-c("predicted","actual")
matrix_dimensions
error_cost<-matrix(c(0,1,5,0),nrow=2,dimnames=matrix_dimensions)
error_cost

#建立模型并评估
credit_treecost<-C5.0(credit_train[-17],credit_train$default,costs=error_cost)
summary(credit_treecost)

credit_treecost_pred<-predict(credit_treecost,credit_test)
CrossTable(credit_test$default,credit_treecost_pred,prop.chisq=FALSE,
           prop.c=FALSE,prop.r=FALSE,dnn=c('actual default','predict default'))


