#数据探索

sms_raw<-read.csv("sms_message.csv",stringsAsFactors=FALSE)
str(sms_raw)
sms_raw$type<-factor(sms_raw$type)
str(sms_raw$type)
table(sms_raw$type)

#数据预处理

#安装tm添加包并加载
install.packages("tm")
library(tm)

#创建语料库
sms_corpus<-Corpus(VectorSource(sms_raw$text))

print(sms_corpus)
inspect(sms_corpus[1:5])

#数据转换
corpus_clean<-tm_map(sms_corpus,tolower)
inspect(corpus_clean[1:5])

corpus_clean<-tm_map(corpus_clean,removeNumbers)
inspect(corpus_clean[1:5])

corpus_clean<-tm_map(corpus_clean,removeWords,stopwords())
inspect(corpus_clean[1:5])

corpus_clean<-tm_map(corpus_clean,removePunctuation)
inspect(corpus_clean[1:5])

corpus_clean<-tm_map(corpus_clean,stripWhitespace)
inspect(corpus_clean[1:5])

#建立文档-词条矩阵
sms_dtm<-DocumentTermMatrix(corpus_clean)
sms_dtm
inspect(sms_dtm[1:5,10:16])

findAssocs(sms_dtm,"free",0.3)
findFreqTerms(sms_dtm,150)

#划分数据集

#创建垃圾短信和正常短信子集
spam<-subset(sms_raw,type=="1")
ham<-subset(sms_raw,type=="0")

spam_corpus<-Corpus(VectorSource(spam$text))             	#建立垃圾短信语料库
spam_clean<-tm_map(spam_corpus,tolower)            		    #转换语料库，变成小写字母
spam_clean<-tm_map(spam_clean,removeNumbers)             	#去除所有数字
spam_clean<-tm_map(spam_clean,removeWords,stopwords())	   #去除停用词
spam_clean<-tm_map(spam_clean,removePunctuation)        	#去除标点符号
spam_clean<-tm_map(spam_clean,stripWhitespace)          	#去除额外空格
spam_dtm<-DocumentTermMatrix(spam_clean)       			       #创建垃圾短信文档-词条矩阵

ham_corpus<-Corpus(VectorSource(ham$text))                	#建立正常短信语料库
ham_clean<-tm_map(ham_corpus,tolower)
ham_clean<-tm_map(ham_clean,removeNumbers)
ham_clean<-tm_map(ham_clean,removeWords,stopwords())
ham_clean<-tm_map(ham_clean,removePunctuation)
ham_clean<-tm_map(ham_clean,stripWhitespace)
ham_dtm<-DocumentTermMatrix(ham_clean)

#探索垃圾短信文档-词条矩阵
spam_dtm
findFreqTerms(spam_dtm,100)

#探索正常短信文档-词条矩阵
ham_dtm
findFreqTerms(ham_dtm,100)

#划分训练集和测试集
sms_raw_train<-sms_raw[1:4169,]
sms_raw_test<-sms_raw[4170:5559,]

sms_dtm_train<-sms_dtm[1:4169,]
sms_dtm_test<-sms_dtm[4170:5559,]

sms_corpus_train<-corpus_clean[1:4169]
sms_corpus_test<-corpus_clean[4170:5559]

#两数据集中各类短信的占比
prop.table(table(sms_raw_train$type))
prop.table(table(sms_raw_test$type)) 

#词云分析
install.packages("wordcloud")
library(wordcloud)

wordcloud(corpus_clean,min.freq=50,scale=c(3,.5),random.order=FALSE)

wordcloud(sms_corpus_train,min.freq=50,scale=c(3,.5),random.order=FALSE)
wordcloud(sms_corpus_test,min.freq=50,scale=c(3,.5),random.order=FALSE)

wordcloud(spam_clean, max.words=40,scale=c(4,.5),random.order=FALSE)
wordcloud(ham_clean, max.words=40,scale=c(4,.5),random.order=FALSE)

#模型训练与评估

#数据准备
sms_dict <- findFreqTerms(sms_dtm,5)
sms_train <- DocumentTermMatrix(sms_corpus_train, list(dictionary = sms_dict))
sms_test <- DocumentTermMatrix(sms_corpus_test, list(dictionary = sms_dict))

convert_count <- function(x) {
  x <- ifelse(x > 0, 1, 0)
  x <- factor(x, levels = c(0, 1), labels = c("No", "Yes"))
  return(x)
}

sms_train <- apply(sms_train, MARGIN = 2, convert_count)
sms_test <- apply(sms_test, MARGIN = 2, convert_count)

#模型训练
install.packages("e1071")
library(e1071)

sms_classifier <- naiveBayes(sms_train, sms_raw_train$type)

#模型评估
sms_test_pred <- predict(sms_classifier, sms_test)

install.packages("gmodels")
library(gmodels)
CrossTable(sms_test_pred, sms_raw_test$type, prop.chisq = FALSE, prop.t = FALSE,
             prop.r = FALSE,dnn = c('predicted', 'actual'))

